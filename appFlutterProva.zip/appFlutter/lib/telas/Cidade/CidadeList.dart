import 'dart:io';

import 'package:appFlutter/dominio/Cidade.dart';
import 'package:appFlutter/service/Helper.dart';
import 'package:appFlutter/telas/Cidade/CidadeEdit.dart';
import 'package:appFlutter/telas/util/Dialogos.dart';
import 'package:flutter/material.dart';
import 'package:appFlutter/telas/Cidade/CidadeList.dart';

class CidadePage extends StatefulWidget {
  CidadePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _CidadePageState createState() => _CidadePageState();
}

class _CidadePageState extends State<CidadePage> {
  CidadeHelper db = CidadeHelper();
  List<Cidade> cidades = List<Cidade>();

  @override
  void initState() {
    super.initState();

    _exibeTodosCidades();
  }

  void _exibeTodosCidades() {
    db.getCidades().then((lista) {
      setState(() {
        cidades = lista;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("Cidades"),
        backgroundColor: Colors.indigo,
        centerTitle: true,
        actions: <Widget>[],
      ),
      backgroundColor: Colors.white,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _exibeCidadeEdit();
        },
        child: Icon(Icons.add),
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(10.0),
        itemCount: cidades.length,
        itemBuilder: (context, index) {
          return _listaCidades(context, index);
        },
      ),
    );
  }

  _listaCidades(BuildContext context, int index) {
    return GestureDetector(
      child: Card(
        child: Padding(
          padding: EdgeInsets.all(10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              Container(
                width: 70.0,
                height: 70.0,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                      image: cidades[index].imagem != null
                          ? FileImage(File(cidades[index].imagem))
                          : AssetImage("images/cidade.png")),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      cidades[index].nome ?? "",
                      style: TextStyle(fontSize: 20),
                    ),
                    Text(
                      cidades[index].estado ?? "",
                      style: TextStyle(fontSize: 15),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: Icon(Icons.delete),
                onPressed: () {
                  _confirmaExclusao(context, cidades[index].id, index);
                },
              ),
            ],
          ),
        ),
      ),
      onTap: () {
        _exibeCidadeEdit(cidade: cidades[index]);
      },
    );
  }

  void _exibeCidadeEdit({Cidade cidade}) async {
    final cidadeRecebido = await Navigator.push(context,
        MaterialPageRoute(builder: (context) => CidadeEdit(cidade: cidade)));

    if (cidadeRecebido != null) {
      if (cidade != null) {
        await db.updateCidade(cidadeRecebido);
      } else {
        await db.insertCidade(cidadeRecebido);
      }
      _exibeTodosCidades();
    }
  }

  void _confirmaExclusao(BuildContext context, int cidadeid, index) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: new Text("Excluir Cidade"),
            content: new Text("Confirma a exclusão do Cidade"),
            actions: <Widget>[
              new FlatButton(
                child: new Text("Cancelar"),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
              FlatButton(
                child: Text("Excluir"),
                onPressed: () {
                  setState(() {
                    cidades.removeAt(index);
                    db.deletarCidade(cidadeid);
                  });
                  Navigator.of(context).pop();
                },
              )
            ],
          );
        });
  }
}
