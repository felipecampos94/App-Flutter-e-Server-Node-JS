import 'dart:io';

import 'package:appFlutter/dominio/Cidade.dart';
import 'package:appFlutter/service/Helper.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class CidadeEdit extends StatefulWidget {
  final Cidade cidade;

  CidadeEdit({this.cidade});

  @override
  _CidadeEditState createState() => _CidadeEditState();
}

class _CidadeEditState extends State<CidadeEdit> {
  final _nomeController = TextEditingController();
  final _emailController = TextEditingController();
  final _nomeFocus = FocusNode();

  bool editado = false;
  Cidade _editaCidade;

  @override
  void initState() {
    super.initState();

    if (widget.cidade == null) {
      _editaCidade = Cidade(null, '', '', null);
    } else {
      _editaCidade = Cidade.fromMap(widget.cidade.toMap());

      _nomeController.text = _editaCidade.nome;
      _emailController.text = _editaCidade.estado;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        title: Text(
            _editaCidade.nome == '' ? "Nova Cidade" : _editaCidade.nome),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          if (_editaCidade.nome != null && _editaCidade.nome.isNotEmpty) {
            Navigator.pop(context, _editaCidade);
          } else {
            _exibeAviso();
            FocusScope.of(context).requestFocus(_nomeFocus);
          }
        },
        child: Icon(Icons.save),
        backgroundColor: Colors.indigo,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10.0),
        child: Column(
          children: <Widget>[
            GestureDetector(
              child: Container(
                width: 70.0,
                height: 70.0,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                      image: _editaCidade.imagem != null
                          ? FileImage(File(_editaCidade.imagem))
                          : AssetImage("images/cidade.png")),
                ),
              ),
              onTap: () {
                ImagePicker.pickImage(source: ImageSource.gallery).then((file) {
                  if (file == null) return;
                  setState(() {
                    _editaCidade.imagem = file.path;
                  });
                });
              },
            ),
            TextField(
              controller: _nomeController,
              focusNode: _nomeFocus,
              decoration: InputDecoration(labelText: "Nome"),
              onChanged: (text) {
                editado = true;
                setState(() {
                  _editaCidade.nome = text;
                });
              },
            ),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: "Estado"),
              onChanged: (text) {
                editado = true;
                _editaCidade.estado = text;
              },

            ),
          ],
        ),
      ),
    );
  }

  void _exibeAviso() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: new Text("Nome"),
            content: new Text("Informe o nome do cidade"),
            actions: <Widget>[
              new FlatButton(
                child: new Text("Fechar"),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              )
            ],
          );
        });
  }
}
