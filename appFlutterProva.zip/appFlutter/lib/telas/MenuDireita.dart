import 'package:flutter/material.dart';

class MenuDireita extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return PopupMenuButton(
        onSelected: (rota) {
          Navigator.of(context).pushNamed(rota);
        },


        itemBuilder: (context) => [
              PopupMenuItem(
                value: '/contador',
                child: Row(
                  children: [Icon(Icons.edit), Text('Contador')],
                ),
              ),
              PopupMenuItem(
                value: '/sobre',
                child: Row(
                  children: [Icon(Icons.delete), Text('Sobre')],
                ),
              ),
              PopupMenuItem(
                value: '/pessoa',
                child: Row(
                  children: [Icon(Icons.delete), Text('Pessoas')],
                ),
              ),
            ]);
  }
}
