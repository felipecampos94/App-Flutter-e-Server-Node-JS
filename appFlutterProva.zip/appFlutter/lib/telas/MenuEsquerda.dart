import 'package:flutter/material.dart';

class MenuEsquerda extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      // Add a ListView to the drawer. This ensures the user can scroll
      // through the options in the drawer if there isn't enough vertical
      // space to fit everything.
      child: ListView(
        // Important: Remove any padding from the ListView.
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            child: Text('App Flutter'),
            decoration: BoxDecoration(
                // image: DecorationImage(
                //   fit: BoxFit.fill,
                //     image: AssetImage('images/menu.png'))

                ),
          ),
          ListTile(
            leading: Icon(Icons.add),
            title: Text('Contador'),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/contador');
            },
          ),
          ListTile(
            leading: Icon(Icons.app_blocking),
            title: Text('Sobre'),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/sobre');
            },
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text('Pessoas'),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/pessoa');
            },
          ),
          ListTile(
            leading: Icon(Icons.flag),
            title: Text('Cidades'),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/cidade');
            },
          ),
          ListTile(
            leading: Icon(Icons.computer),
            title: Text('Eventos'),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).pushNamed('/evento');
            },
          ),

        ],
      ),
    );
  }
}
