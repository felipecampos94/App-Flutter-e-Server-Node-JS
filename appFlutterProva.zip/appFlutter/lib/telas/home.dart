import 'package:appFlutter/telas/MenuDireita.dart';
import 'package:appFlutter/telas/MenuEsquerda.dart';
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  HomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MenuEsquerda(),

      appBar: AppBar(
        title: Text(title),
        actions: [
          Text('App Flutter'),
          MenuDireita()

        ],
      ),
      body: Center(
        child: Container(
          padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Text('Tela principal do APP'),
              RaisedButton(
                child: Text('Abrir Contador'),
                onPressed: () {
                  Navigator.of(context).pushNamed('/contador');
                },
              ),
              RaisedButton(
                child: Text('Abrir Sobre'),
                onPressed: () {
                  Navigator.of(context).pushNamed('/sobre');
                },
              ),
              RaisedButton(
                child: Text('Pessoas'),
                onPressed: () {
                  Navigator.of(context).pushNamed('/pessoa');
                },
              ),
              RaisedButton(
                child: Text('Eventos'),
                onPressed: () {
                  Navigator.of(context).pushNamed('/evento');
                },
              ),
              RaisedButton(
                child: Text('Adicionar Evento'),
                onPressed: () {
                  Navigator.of(context).pushNamed('/eventoEdit');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
