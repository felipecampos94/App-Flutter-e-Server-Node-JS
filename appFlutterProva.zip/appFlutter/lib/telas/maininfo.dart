import 'package:flutter/material.dart';

class MaisInfoPage extends StatelessWidget {
  final String resultado;
  MaisInfoPage({Key key, @required this.resultado}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Resultados obtidos'),
      ),
      body: Container(
        color: Colors.cyan,
        child: Center(
          child: Text(resultado), 
        ),
      ),
    );
  }
}