import 'package:appFlutter/dominio/Pessoa.dart';
import 'package:appFlutter/service/PessoaServ.dart';
import 'package:appFlutter/telas/Pessoa/PessoaEdit.dart';
import 'package:appFlutter/telas/util/Dialogos.dart';
import 'package:flutter/material.dart';

class PessoaPage extends StatefulWidget {
  PessoaPage({Key key, this.title}) : super(key: key);
  final String title;

  // usar a classe de serviço
  PessoaServ api = new PessoaServ();

  @override
  _PessoaPageState createState() => _PessoaPageState();
}

class _PessoaPageState extends State<PessoaPage> {
  // Atributo com uma lista de pessoas
  List<Pessoa> lista = new List();

  @override
  void initState() {
    super.initState();
    obterPessoas();
  }

  void obterPessoas() {
    widget.api.obterTodos().then((value) => {
          setState(() {
            lista = value;
          })
        });
  }

  void _addPessoa() async {
    Pessoa p = new Pessoa();
    final res = await Navigator.of(context)
        .push(MaterialPageRoute(builder: (context) => PessoaEdit(objeto: p)));
    //print(res);
    obterPessoas();
    Dialogos.showToastSuccess(res);
  }

  void selecinarPessoa(Pessoa p) async {
    //print("pessoa selecionada: "+p.nome);
    final res = await Navigator.of(context)
        .push(MaterialPageRoute(builder: (context) => PessoaEdit(objeto: p)));
    //print(res);
    obterPessoas();
    Dialogos.showToastSuccess(res);
  }

  void excluir(Pessoa p) async {
    //print(p);
    Dialogos.showConfirmDialog(
        context,
        'Confirma exclusão?',
        () => {
              widget.api
                  .excluir(p)
                  .then((value) =>
                      {obterPessoas(), Dialogos.showToastSuccess('Excluiu')})
                  .catchError((e) => {print(e)})
            });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
          child: ListView(
              padding: EdgeInsets.all(10.0),
              scrollDirection: Axis.vertical,
              children: lista
                  .map(
                    (data) => ListTile(
                      leading: Icon(Icons.person),
                      title: Text(data.nome),
                      trailing: PopupMenuButton(
                          onSelected: (op) {
                            if (op == 'editar') {
                              selecinarPessoa(data);
                            } else {
                              excluir(data);
                            }
                          },
                          itemBuilder: (context) => [
                                PopupMenuItem(
                                  value: 'editar',
                                  child: Row(
                                    children: [
                                      Icon(Icons.edit),
                                      Text('Editar')
                                    ],
                                  ),
                                ),
                                PopupMenuItem(
                                  value: 'excluir',
                                  child: Row(
                                    children: [
                                      Icon(Icons.delete),
                                      Text('Excluir')
                                    ],
                                  ),
                                ),
                              ]),
                      onTap: () => selecinarPessoa(data),
                    ),
                  )
                  .toList())),
      floatingActionButton: FloatingActionButton(
        onPressed: _addPessoa,
        tooltip: 'Adicionar uma pessoa',
        child: Icon(Icons.person_add),
      ),
    );
  }
}
