import 'package:appFlutter/dominio/Pessoa.dart';
import 'package:appFlutter/service/PessoaServ.dart';
import 'package:flutter/material.dart';

class PessoaEdit extends StatefulWidget {
  PessoaEdit({Key key, this.objeto}) : super(key: key);
  final Pessoa objeto;

  // usar a classe de serviço
  PessoaServ api = new PessoaServ();

  @override
  _PessoaEditState createState() => _PessoaEditState();
}

class _PessoaEditState extends State<PessoaEdit> {
  // Atributo com uma pessoa
  Pessoa objeto;

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    objeto = widget.objeto;
  }

  void _salvar() {
    if (_formKey.currentState.validate()) {
      if (objeto.id == null) {
        widget.api
            .incluir(objeto)
            .then((value) => {Navigator.pop(context, 'salvou')})
            .catchError((e) => {print(e)});
      } else {
        widget.api
            .alterar(objeto)
            .then((value) => {Navigator.pop(context, 'salvou')})
            .catchError((e) => {print(e)});
      }
    }
  }

  void _cancelar() {
    Navigator.pop(context, 'cancelou');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edição de Pessoa'),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(10.0),
          child: Form(
            key: _formKey,
            child: Column(children: <Widget>[
              // Add TextFormFields and ElevatedButton here.
              TextFormField(
                keyboardType: TextInputType.text,
                maxLength: 50,
                decoration: InputDecoration(
                  icon: Icon(Icons.person),
                  border: OutlineInputBorder(),
                  labelText: 'Informe o nome',
                ),
                initialValue: objeto.nome,
                onChanged: (text) {
                  objeto.nome = text;
                },
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Informe o nome';
                  }
                  return null;
                },
              ),

              TextFormField(
                keyboardType: TextInputType.emailAddress,
                maxLength: 80,
                decoration: InputDecoration(
                  icon: Icon(Icons.mail),
                  border: OutlineInputBorder(),
                  labelText: 'Informe o email',
                ),
                initialValue: objeto.email,
                onChanged: (text) {
                  objeto.email = text;
                },
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Informe o email';
                  }
                  if (!value.contains('@')) {
                    return 'Informe um email válido';
                  }
                  return null;
                },
              ),

              // Fim dos TextFormFields and ElevatedButton here.

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton.icon(
                      onPressed: _salvar,
                      icon: Icon(Icons.save),
                      label: Text('Salvar')),
                  SizedBox(
                    width: 10,
                  ),
                  ElevatedButton.icon(
                      onPressed: _cancelar,
                      icon: Icon(Icons.cancel),
                      label: Text('Cancelar')),
                ],
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
