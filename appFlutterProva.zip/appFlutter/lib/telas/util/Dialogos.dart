import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Dialogos {
  static showAlertDialog(BuildContext context, String mensagem) {
    // definir um botão de ok
    Widget okButton = FlatButton(
      child: Text('Ok'),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );
    // configurar o AlertDialog
    AlertDialog dialogo = AlertDialog(
      title: Text('Alerta'),
      content: SingleChildScrollView(
        child: ListBody(
          children: <Widget>[
            Text(mensagem),
          ],
        ),
      ),
      actions: [okButton],
    );
    // exibir o dialogo
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return dialogo;
        });
  }

  static showConfirmDialog(
      BuildContext context, String mensagem, Function simFunction) {
    // definir um botão de sim
    Widget simButton = FlatButton(
      child: Text('Sim'),
      onPressed: () {
        simFunction();
        Navigator.of(context).pop();
      },
    );
    // definir um botão de sim
    Widget naoButton = FlatButton(
      child: Text('Não'),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );

    // configurar o AlertDialog
    AlertDialog dialogo = AlertDialog(
      title: Text('Alerta'),
      content: SingleChildScrollView(
        child: ListBody(
          children: <Widget>[
            Text(mensagem),
          ],
        ),
      ),
      actions: [simButton, naoButton],
    );
    // exibir o dialogo
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return dialogo;
        });
  }

  static void showToastSuccess(String msg) {
    Fluttertoast.showToast(
        msg: msg,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.green,
        textColor: Colors.white,
        fontSize: 16.0);
  }

  static void showToastError(String msg) {
    Fluttertoast.showToast(
        msg: msg,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0);
  }

  static void showToastAtention(String msg) {
    Fluttertoast.showToast(
        msg: msg,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.yellow,
        textColor: Colors.white,
        fontSize: 16.0);
  }
}
