import 'package:appFlutter/dominio/Evento.dart';
import 'package:appFlutter/service/EventoServ.dart';
import 'package:flutter/material.dart';

class EventoEdit extends StatefulWidget {

  final Evento objeto = Evento();

  // usar a classe de serviço
  EventoServ api = new EventoServ();

  @override
  _EventoEditState createState() => _EventoEditState();
}

class _EventoEditState extends State<EventoEdit> {
  // Atributo com uma evento
  Evento objeto;

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    objeto = widget.objeto;
  }

  void _salvar() {
    print(objeto);
    if (_formKey.currentState.validate()) {
      widget.api
          .incluir(objeto)
          .then((value) => {
        // Navigator.pop(context, 'salvou')
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text("Alerta:"),
              content: Text(
                "Salvo com Sucesso",
              ),
              actions: <Widget>[
                FlatButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text("Ok"),
                ),
              ],
            );
          },
        )
      })
          .catchError((e) => {print(e)});
      _formKey.currentState?.reset();
    }
  }
  void _cancelar() {
    Navigator.of(context).pushNamed('/home');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [],
        title: Text('Formulário'),
      ),

      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(10.0),
          child: Form(
            key: _formKey,
            child: Column(children: <Widget>[
              // Add TextFormFields and ElevatedButton here.
              TextFormField(
                keyboardType: TextInputType.text,
                maxLength: 50,
                decoration: InputDecoration(
                  icon: Icon(Icons.description),
                  border: OutlineInputBorder(),
                  labelText: 'Informe o nome',
                ),
                initialValue: objeto.nome,
                onChanged: (text) {
                  objeto.nome = text;
                },
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Informe o nome';
                  }
                  return null;
                },
              ),

              TextFormField(
                keyboardType: TextInputType.text,
                maxLength: 30,
                decoration: InputDecoration(
                  icon: Icon(Icons.add_location),
                  border: OutlineInputBorder(),
                  labelText: 'Informe o local',
                ),
                initialValue: objeto.local,
                onChanged: (text) {
                  objeto.local = text;
                },
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Informe o local';
                  }
                  return null;
                },
              ),
              TextFormField(
                keyboardType: TextInputType.text,
                maxLength: 5,
                decoration: InputDecoration(
                  icon: Icon(Icons.access_time),
                  border: OutlineInputBorder(),
                  labelText: 'Informe o horário',
                ),
                initialValue: objeto.horario,
                onChanged: (text) {
                  objeto.horario = text;
                },
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Informe o horário';
                  }
                  return null;
                },
              ),
              TextFormField(
                keyboardType: TextInputType.datetime,
                decoration: InputDecoration(
                  icon: Icon(Icons.calendar_today),
                  border: OutlineInputBorder(),
                  labelText: 'Informe a data',
                ),
                initialValue: objeto.data,
                onChanged: (text) {
                  objeto.data = text;
                },
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Informe a data';
                  }
                  return null;
                },
              ),
              //Fim dos TextFormFields and ElevatedButton here.

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton.icon(
                      onPressed: _salvar,
                      icon: Icon(Icons.save),
                      label: Text('Salvar')),
                  SizedBox(
                    width: 10,
                  ),
                  ElevatedButton.icon(
                      onPressed: _cancelar,
                      icon: Icon(Icons.cancel),
                      label: Text('Cancelar')),
                ],
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
