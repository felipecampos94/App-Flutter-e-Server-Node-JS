import 'package:appFlutter/dominio/Evento.dart';
import 'package:appFlutter/service/EventoServ.dart';
import 'package:appFlutter/telas/Evento/EventoEdit.dart';
import 'package:appFlutter/telas/util/Dialogos.dart';
import 'package:flutter/material.dart';

class EventoPage extends StatefulWidget {
  EventoPage({Key key, this.title}) : super(key: key);
  final String title;

  // usar a classe de serviço
  EventoServ api = new EventoServ();

  @override
  _EventoPageState createState() => _EventoPageState();
}

class _EventoPageState extends State<EventoPage> {
  // Atributo com uma lista de eventos
  List<Evento> lista = new List();

  @override
  void initState() {
    super.initState();
    obterEventos();
  }

  void obterEventos() {
    widget.api.obterTodos().then((value) => {
          setState(() {
            lista = value;
          })
        });
  }

  // void _addEvento() async {
  //   Evento e = new Evento();
  //   final res = await Navigator.of(context)
  //       .push(MaterialPageRoute(builder: (context) => EventoEdit(objeto: e)));
  //   //print(res);
  //   obterEventos();
  //   Dialogos.showToastSuccess(res);
  // }

  // void selecinarEvento(Evento e) async {
  //   //print("evento selecionada: "+p.nome);
  //   final res = await Navigator.of(context)
  //       .push(MaterialPageRoute(builder: (context) => EventoEdit(objeto: e)));
  //   //print(res);
  //
  //   Dialogos.showToastSuccess(res);
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
          child: ListView(
              padding: EdgeInsets.all(10.0),
              scrollDirection: Axis.vertical,
              children: lista
                  .map(
                    (data) => ListTile(
                      leading: Icon(Icons.event),
                      title: Text(data.nome),
                      onTap: () => showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text("Alerta:"),
                            content: Text(
                              "Nome: " + data.nome,

                            ),

                            actions: <Widget>[
                              FlatButton(
                                onPressed: () => Navigator.of(context).pop(),
                                child: Text("Ok"),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  )
                  .toList())),
    );
  }
}
