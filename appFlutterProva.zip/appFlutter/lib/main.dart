import 'package:appFlutter/telas/Evento/EventoEdit.dart';
import 'package:appFlutter/telas/Evento/EventoList.dart';
import 'package:appFlutter/telas/Pessoa/PessoaList.dart';
import 'package:flutter/material.dart';
import 'package:appFlutter/telas/contador.dart';
import 'package:appFlutter/telas/home.dart';
import 'package:appFlutter/telas/sobre.dart';
import 'package:appFlutter/telas/Cidade/CidadeList.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final String titulo = "Primeiro App"; 

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.green,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomePage(title: titulo), 
      routes: {
         '/home': (context) => HomePage(title: titulo,), 
         '/contador': (context) => ContadorPage(title: "Exemplo Contador",), 
         '/sobre': (context) => SobrePage(title: "Sobre o App",), 
         '/pessoa': (context) => PessoaPage(title: "Pessoas",),
         '/cidade': (context) => CidadePage(title: "Cidades",),
         '/evento': (context) => EventoPage(title: "Eventos",),
         '/eventoEdit': (context) => EventoEdit(),
      },
    );
  }
}
