class Evento {
  String id;
  String nome;
  String local;
  String horario;
  String data;

  Evento();

  Evento.initId(this.id);

  Evento.init(this.id, this.nome, this.local, this.horario, this.data);

  @override
  String toString() {
    return nome;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'nome': nome,
        'local': local,
        'horario': horario,
        'data': data
      };

  factory Evento.fromJson(Map<String, dynamic> json) {
    return Evento.init(
        json['_id'],
        json['nome'],
        json['local'],
        json['horario'],
        json['data']);
  }
}
