class Pessoa{
   String id;
   String nome;
   String email;

   Pessoa();
   Pessoa.initId(this.id);
   Pessoa.init(this.id, this.nome, this.email);

  @override
  String toString() {
      return nome;
  }

  Map<String, dynamic> toJson() => {
      'id': id,
      'nome': nome,
      'email': email,
  }; 

  factory Pessoa.fromJson(Map<String, dynamic> json){
    return Pessoa.init(
      json['_id'], 
      json['nome'] , 
      json['email']);
  }

}