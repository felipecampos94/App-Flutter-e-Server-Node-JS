import 'dart:io';

import 'package:appFlutter/dominio/Cidade.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class CidadeHelper {
  static CidadeHelper _cidadeHelper;
  static Database _database;

  //usada para definir as colunas da tabela
  String cidadeTable = 'cidade';
  String colId = 'id';
  String colNome = 'nome';
  String colEstado = 'estado';
  String colImagem = 'imagem';

  //construtor nomeado para criar instância da classe
  CidadeHelper._createInstance();

  factory CidadeHelper() {
    if (_cidadeHelper == null) {
      //executado somente uma vez
      _cidadeHelper = CidadeHelper._createInstance();
    }
    return _cidadeHelper;
  }

  Future<Database> get database async {
    if (_database == null) {
      _database = await initializeDatabase();
    }
    return _database;
  }

  Future<Database> initializeDatabase() async {
    Directory directory = await getApplicationDocumentsDirectory();
    String path = directory.path + 'cidades.db';

    var cidadesDatabase =
    await openDatabase(path, version: 1, onCreate: _createDb);
    return cidadesDatabase;
  }

  void _createDb(Database db, int newVersion) async {
    await db.execute(
        'CREATE TABLE $cidadeTable($colId INTEGER PRIMARY KEY AUTOINCREMENT,'
            '$colNome TEXT, '
            '$colEstado TEXT, $colImagem TEXT)');
  }

  //Incluir um objeto no banco de dados
  Future<int> insertCidade(Cidade cidade) async {
    Database db = await this.database;
    var resultado = await db.insert(cidadeTable, cidade.toMap());
    return resultado;
  }

  // retorna um contato pelo id
  Future<Cidade> getCidade(int id) async {
    Database db = await this.database;

    List<Map> maps = await db.query(cidadeTable,
        columns: [colId, colNome, colEstado, colImagem],
        where: "$colId = ?",
        whereArgs: [id]);

    if (maps.length > 0) {
      return Cidade.fromMap(maps.first);
    } else {
      return null;
    }
  }

  Future<List<Cidade>> getCidades() async {
    Database db = await this.database;

    var resultado = await db.query(cidadeTable);

    List<Cidade> lista = resultado.isNotEmpty
        ? resultado.map((c) => Cidade.fromMap(c)).toList()
        : [];

    return lista;
  }

  //Atualizar o registro no banco de dados
  Future<int> updateCidade(Cidade cidade) async {
    var db = await this.database;

    var resultado = await db.update(cidadeTable, cidade.toMap(),
        where: '$colId = ?', whereArgs: [cidade.id]);

    return resultado;
  }

  //Deletar um registro no banco de dados
  Future<int> deletarCidade(int id) async {
    var db = await this.database;

    int resultado =
    await db.delete(cidadeTable, where: "$colId = ?", whereArgs: [id]);

    return resultado;
  }

  //Retorna a quantidade de registros do banco de dados
  Future<int> getCount() async {
    Database db = await this.database;
    List<Map<String, dynamic>> x =
    await db.rawQuery('SELECT COUNT (*) from $cidadeTable');

    int resultado = Sqflite.firstIntValue(x);
    return resultado;
  }

  //Fecha o banco de dados
  Future close() async {
    Database db = await this.database;
    db.close();
  }
}
