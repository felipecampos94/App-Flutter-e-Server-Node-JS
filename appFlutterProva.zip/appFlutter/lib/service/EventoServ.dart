import 'dart:convert';
import 'package:appFlutter/dominio/Evento.dart';
import 'package:http/http.dart' as http;

class EventoServ {
  String url = 'http://192.168.0.3:3000/eventos';

  Future<List<Evento>> obterTodos() async {
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final parsed = jsonDecode(response.body).cast<Map<String, dynamic>>();
      return parsed.map<Evento>((json) => Evento.fromJson(json)).toList();
    } else {
      throw Exception('Falha ao recuperar eventos');
    }
  }

  Future<Evento> incluir(Evento obj) async {
    final response = await http.post(url,
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8'
        },
        body: jsonEncode(obj.toJson()));
    if (response.statusCode != 200) {
      throw Exception('Falha ao incluir evento');
    }
  }
}
