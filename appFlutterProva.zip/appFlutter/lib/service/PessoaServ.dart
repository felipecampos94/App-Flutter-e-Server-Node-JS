import 'dart:convert';
import 'package:appFlutter/dominio/Pessoa.dart';
import 'package:http/http.dart' as http;

class PessoaServ{
  String url = 'http://192.168.0.3:3000/pessoas';

  Future<List<Pessoa>> obterTodos() async {
     final response = await  http.get(url);
     if (response.statusCode == 200){ 
        final parsed = jsonDecode(response.body).cast<Map<String, dynamic>>();  
        return parsed.map<Pessoa>((json) => Pessoa.fromJson(json)).toList(); 
     } else {
       throw Exception('Falha ao recuperar pessoas');
     }
  } 

  Future<Pessoa> alterar(Pessoa obj) async {
     final response = await  http.put(url,
        headers: <String, String>{'Content-Type':'application/json; charset=UTF-8'},
        body: jsonEncode(obj.toJson())
     );
     if (response.statusCode != 200){ 
       throw Exception('Falha ao alterar pessoa');
     }
  } 

  Future<Pessoa> incluir(Pessoa obj) async {
     final response = await  http.post(url,
        headers: <String, String>{'Content-Type':'application/json; charset=UTF-8'},
        body: jsonEncode(obj.toJson())
     );
     if (response.statusCode != 200){ 
       throw Exception('Falha ao incluir pessoa');
     }
  } 

  Future<Pessoa> excluir(Pessoa obj) async {
     final response = await  http.delete(url+'/'+obj.id,
        headers: <String, String>{'Content-Type':'application/json; charset=UTF-8'},
     );
     if (response.statusCode != 200){ 
       throw Exception('Falha ao excluir pessoa');
     }
  } 






}