// npm init no console e enter para tudo
console.log('Arquivo server executou!');
// agora instalar alguns pacotes
// npm install express --save
// npm install mongodb --save
// npm install nodemon --save-dev 
//     - editar package.json e add script dev: nodemon server.js 
//     - para rodar passar a usar o comando: npm run dev 


// usar o express em nossa api
const express = require('express');
const app = express();
// para trabalhar com json
app.use(express.json());

// para nossa api usar o mongo
const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb://localhost:27017/auladampf"
const ObjectId = require('mongodb').ObjectID;

MongoClient.connect(uri, (err, client) => {
   if (err) return console.log(err);
   // estando conectado, selecionar nossa base
   db = client.db('auladampf');
   
   app.listen(3000, function(){
      console.log('Sevidor rodando na porta 3000.  http://localhost:3000 ');
   });   

} )


// Adicionar um método para atender requisições GET
app.get('/', (req, res) => {
    res.send('Resposta de nosso servidor...');    
});

// obter pessoas
app.get('/pessoas', (req, res) => {
    db.collection('pessoas').find().toArray( (err, results) => {
        if (err) return console.log(err);   
        res.json(results);
    });
});

// inserir pessoa
app.post('/pessoas', (req, res) => {
    db.collection('pessoas').insertOne(req.body, (err, result) => {
        if (err) return console.log(err);   
        res.json( {'message':'Incluído'} );
    });     
});

// alterar pessoa
app.put('/pessoas', (req, res) => {
    db.collection('pessoas').updateOne({_id: ObjectId(req.body.id)}, {$set:req.body}, (err, result) => {
        if (err) return console.log(err);   
        res.json( {'message':'Alerado'} );
    });
});

// deletar pessoa
app.delete('/pessoas/:id', (req, res) => {
    db.collection('pessoas').deleteOne({_id: ObjectId(req.params.id)}, (err, result) => {
        if (err) return console.log(err);   
        res.json( {'message':'Excluído'} );
    });
});



// Tabela Evento

// obter eventos
app.get('/eventos', (req, res) => {
    db.collection('eventos').find().toArray( (err, results) => {
        if (err) return console.log(err);
        res.json(results);
    });
});

app.get('/inserirevento', (req, res) => {
    db.collection('eventos').find().toArray( (err, results) => {
        if (err) return console.log(err);
        res.json(results);
    });
});

// inserir
app.post('/eventos', (req, res) => {
    db.collection('eventos').insertOne(req.body, (err, result) => {
        if (err) return console.log(err);
        res.json( {'message':'Incluído'} );
    });
});

